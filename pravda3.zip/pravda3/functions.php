<?php
// functions.php — регистрация CPT, таксономий, метабоксов, enqueue assets, шорткоды
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'after_setup_theme', 'bc_theme_setup' );
function bc_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    register_nav_menus( array( 'primary' => 'Primary Menu' ) );
}

add_action( 'wp_enqueue_scripts', 'bc_enqueue_assets' );
function bc_enqueue_assets() {
    $v = '20260226';
    $t = get_template_directory_uri();
    wp_enqueue_style( 'bc-style', $t . '/css/style.min.css', array(), $v );
    // Подключаем файл с исправлениями (после основного)
    wp_enqueue_style( 'bc-fixes', $t . '/css/fixes.css', array('bc-style'), $v );
    wp_enqueue_script( 'bc-app', $t . '/js/app.min.js', array('jquery'), $v, true );
    // Надёжный скрипт мобильного меню
    wp_enqueue_script( 'bc-mobile-menu', $t . '/js/mobile-menu.js', array(), $v, true );
}

// Register CPT: broker, news, complaint, faq
add_action( 'init', 'bc_register_cpts' );
function bc_register_cpts() {
    // Broker
    register_post_type( 'broker', array(
        'labels' => array(
            'name' => 'Брокеры',
            'singular_name' => 'Брокер',
            'add_new_item' => 'Добавить брокера',
            'edit_item' => 'Редактировать брокера',
            'all_items' => 'Все брокеры',
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array( 'slug' => 'brokers' ),
        'supports' => array( 'title','editor','thumbnail','excerpt','comments' ),
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-building',
    ) );

    // News
    register_post_type( 'bc_news', array(
        'labels' => array('name'=>'Новости','singular_name'=>'Новость','add_new_item'=>'Добавить новость'),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array( 'slug' => 'news' ),
        'supports' => array( 'title','editor','thumbnail','excerpt' ),
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-admin-post',
    ) );

    // Complaint
    register_post_type( 'complaint', array(
        'labels' => array('name'=>'Жалобы','singular_name'=>'Жалоба'),
        'public' => false,
        'show_ui' => true,
        'supports' => array('title','editor'),
        'menu_icon' => 'dashicons-warning',
    ) );

    // FAQ
    register_post_type( 'bc_faq', array(
        'labels' => array(
            'name' => 'FAQ / Факты',
            'singular_name' => 'Вопрос/Факт',
            'add_new_item' => 'Добавить вопрос/факт',
            'edit_item' => 'Редактировать',
            'all_items' => 'Все FAQ',
        ),
        'public' => false,
        'show_ui' => true,
        'supports' => array( 'title', 'editor' ),
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-editor-help',
    ) );

    // Taxonomy: broker_status
    register_taxonomy( 'broker_status', 'broker', array(
        'labels' => array('name'=>'Статус брокера','singular_name'=>'Статус'),
        'public' => true,
        'hierarchical' => false,
        'rewrite' => array('slug'=>'broker-status'),
        'show_in_rest' => true,
    ) );
}

// Metaboxes for broker
add_action( 'add_meta_boxes', 'bc_add_broker_meta_boxes' );
function bc_add_broker_meta_boxes() {
    add_meta_box( 'bc_broker_meta', 'Данные брокера', 'bc_broker_meta_callback', 'broker', 'side', 'high' );
    add_meta_box( 'bc_faq_broker', 'FAQ для этого брокера', 'bc_faq_broker_callback', 'broker', 'normal', 'low' );
}

function bc_broker_meta_callback( $post ) {
    wp_nonce_field( 'bc_save_broker_meta', 'bc_broker_meta_nonce' );
    $rating = get_post_meta( $post->ID, '_bc_rating', true );
    $date_added = get_post_meta( $post->ID, '_bc_date_added', true );
    echo '<p><label>Рейтинг (0-5)</label><br><input type="number" step="0.1" min="0" max="5" name="bc_rating" value="'.esc_attr($rating).'" style="width:100%;"></p>';
    echo '<p><label>Дата добавления</label><br><input type="date" name="bc_date_added" value="'.esc_attr($date_added).'" style="width:100%;"></p>';
    echo '<p>Логотип: установить как "Миниатюра записи" (Featured Image)</p>';
}

function bc_faq_broker_callback( $post ) {
    echo '<p style="color:#666; font-size:13px;">FAQ/Факты для этого брокера добавляются в разделе <strong>FAQ / Факты</strong> в меню WordPress. Там можно указать к какому брокеру относится вопрос/факт.</p>';
}

add_action( 'save_post', 'bc_save_broker_meta' );
function bc_save_broker_meta( $post_id ) {
    if ( ! isset( $_POST['bc_broker_meta_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['bc_broker_meta_nonce'], 'bc_save_broker_meta' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( isset( $_POST['bc_rating'] ) ) update_post_meta( $post_id, '_bc_rating', floatval( $_POST['bc_rating'] ) );
    if ( isset( $_POST['bc_date_added'] ) ) update_post_meta( $post_id, '_bc_date_added', sanitize_text_field( $_POST['bc_date_added'] ) );
}

// =============================================
// COMMENT RATING SYSTEM
// =============================================

// Add rating metabox to comment edit screen
add_action( 'add_meta_boxes_comment', 'bc_add_comment_rating_metabox' );
function bc_add_comment_rating_metabox() {
    add_meta_box( 'bc_comment_rating', 'Рейтинг отзыва', 'bc_comment_rating_callback', 'comment', 'normal', 'high' );
}

function bc_comment_rating_callback( $comment ) {
    $rating = get_comment_meta( $comment->comment_ID, 'bc_rating', true );
    wp_nonce_field( 'bc_comment_rating_nonce', 'bc_comment_rating_nonce' );
    ?>
    <p>
        <label><strong>Оценка (1-5 огоньков):</strong></label><br>
        <select name="bc_comment_rating" style="margin-top:5px; padding:5px; border-radius:5px; border:1px solid #ccc;">
            <option value="">— не указана —</option>
            <?php for ($i=1; $i<=5; $i++): ?>
                <option value="<?php echo $i; ?>" <?php selected($rating, $i); ?>><?php echo $i; ?> <?php echo str_repeat('🔥', $i); ?></option>
            <?php endfor; ?>
        </select>
    </p>
    <?php
}

// Save comment rating from admin
add_action( 'edit_comment', 'bc_save_comment_rating' );
function bc_save_comment_rating( $comment_id ) {
    if ( ! isset( $_POST['bc_comment_rating_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['bc_comment_rating_nonce'], 'bc_comment_rating_nonce' ) ) return;
    if ( isset( $_POST['bc_comment_rating'] ) && $_POST['bc_comment_rating'] !== '' ) {
        update_comment_meta( $comment_id, 'bc_rating', intval( $_POST['bc_comment_rating'] ) );
    } else {
        delete_comment_meta( $comment_id, 'bc_rating' );
    }
}

// Save comment rating from frontend form
add_action( 'comment_post', 'bc_save_frontend_comment_rating', 10, 2 );
function bc_save_frontend_comment_rating( $comment_id, $approved ) {
    if ( isset( $_POST['bc_comment_rating'] ) && $_POST['bc_comment_rating'] !== '' ) {
        $rating = intval( $_POST['bc_comment_rating'] );
        if ( $rating >= 1 && $rating <= 5 ) {
            update_comment_meta( $comment_id, 'bc_rating', $rating );
        }
    }
}

// Helper: render fire rating
function bc_render_fire_rating( $rating, $max = 5 ) {
    $rating = intval($rating);
    $output = '<ul class="bc-fire-rating">';
    for ( $i = 1; $i <= $max; $i++ ) {
        $active = $i <= $rating ? 'bc-fire-rating__item--active' : '';
        $output .= '<li class="bc-fire-rating__item ' . $active . '">🔥</li>';
    }
    $output .= '</ul>';
    return $output;
}

// =============================================
// FAQ METABOX — assign FAQ to broker
// =============================================
add_action( 'add_meta_boxes', 'bc_faq_add_broker_meta_box' );
function bc_faq_add_broker_meta_box() {
    add_meta_box( 'bc_faq_broker_id', 'Привязать к брокеру', 'bc_faq_broker_id_callback', 'bc_faq', 'side', 'high' );
    add_meta_box( 'bc_faq_order', 'Порядок отображения', 'bc_faq_order_callback', 'bc_faq', 'side', 'low' );
}

function bc_faq_broker_id_callback( $post ) {
    wp_nonce_field( 'bc_faq_nonce', 'bc_faq_nonce' );
    $broker_id = get_post_meta( $post->ID, '_bc_faq_broker_id', true );
    $brokers = get_posts( array( 'post_type' => 'broker', 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
    echo '<p><label>Выберите брокера (оставьте пустым для общего FAQ):</label></p>';
    echo '<select name="bc_faq_broker_id" style="width:100%; padding:5px; margin-top:5px;">';
    echo '<option value="">— Общий FAQ —</option>';
    foreach ( $brokers as $b ) {
        $selected = selected( $broker_id, $b->ID, false );
        echo '<option value="' . esc_attr($b->ID) . '" ' . $selected . '>' . esc_html($b->post_title) . '</option>';
    }
    echo '</select>';
}

function bc_faq_order_callback( $post ) {
    $order = get_post_meta( $post->ID, '_bc_faq_order', true ) ?: 0;
    echo '<input type="number" name="bc_faq_order" value="' . esc_attr($order) . '" style="width:100%; padding:5px;">';
    echo '<p style="color:#666; font-size:12px;">Чем меньше число, тем выше в списке.</p>';
}

add_action( 'save_post_bc_faq', 'bc_save_faq_meta' );
function bc_save_faq_meta( $post_id ) {
    if ( ! isset( $_POST['bc_faq_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['bc_faq_nonce'], 'bc_faq_nonce' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( isset( $_POST['bc_faq_broker_id'] ) ) {
        update_post_meta( $post_id, '_bc_faq_broker_id', intval( $_POST['bc_faq_broker_id'] ) );
    }
    if ( isset( $_POST['bc_faq_order'] ) ) {
        update_post_meta( $post_id, '_bc_faq_order', intval( $_POST['bc_faq_order'] ) );
    }
}

// =============================================
// SHORTCODES
// =============================================

add_shortcode( 'bc_latest_news', 'bc_shortcode_latest_news' );
function bc_shortcode_latest_news( $atts ) {
    $atts = shortcode_atts( array('count'=>4), $atts );
    $q = new WP_Query( array( 'post_type'=>'bc_news', 'posts_per_page'=>intval($atts['count']) ) );
    ob_start();
    if ( $q->have_posts() ) {
        echo '<div class="bc-latest-news">';
        while ( $q->have_posts() ) {
            $q->the_post();
            $thumb = get_the_post_thumbnail_url( get_the_ID(), 'medium' ) ?: get_template_directory_uri().'/img/news/01.jpg';
            ?>
            <article class="last-news__slide">
                <div class="slide-last-news__image"><img src="<?php echo esc_url($thumb); ?>" alt=""></div>
                <div class="slide-last-news__body">
                    <span class="slide-last-news__date"><?php echo get_the_date('d.m.Y'); ?></span>
                    <a href="<?php the_permalink(); ?>" class="slide-last-news__link-title"><h3 class="slide-last-news__title-link"><?php the_title(); ?></h3></a>
                    <p class="slide-last-news__text"><?php echo wp_trim_words( get_the_excerpt(), 20 ); ?></p>
                    <a href="<?php the_permalink(); ?>" class="slide-last-news__link">Подробнее</a>
                </div>
            </article>
            <?php
        }
        echo '</div>';
        wp_reset_postdata();
    }
    return ob_get_clean();
}

add_shortcode( 'bc_latest_brokers', 'bc_shortcode_latest_brokers' );
function bc_shortcode_latest_brokers( $atts ) {
    $atts = shortcode_atts( array('count'=>6), $atts );
    $q = new WP_Query( array( 'post_type'=>'broker', 'posts_per_page'=>intval($atts['count']) ) );
    ob_start();
    if ( $q->have_posts() ) {
        echo '<div class="brokers-list">';
        while ( $q->have_posts() ) {
            $q->the_post();
            $rating = get_post_meta( get_the_ID(), '_bc_rating', true ) ?: 0;
            ?>
            <div class="brokers__block">
                <a href="<?php the_permalink(); ?>" class="brokers__left">
                    <span class="brokers__logo"><?php if ( has_post_thumbnail() ) the_post_thumbnail('thumbnail'); ?></span>
                    <h3 class="brokers__name"><?php the_title(); ?></h3>
                </a>
                <div class="brokers__content">
                    <p class="brokers__status">Статус: <?php
                        $terms = wp_get_post_terms( get_the_ID(), 'broker_status' );
                        if ( $terms && ! is_wp_error($terms) ) echo '<span>'.esc_html($terms[0]->name).'</span>'; else echo '<span>-</span>';
                    ?></p>
                    <div class="brokers__date-block">
                        <span class="brokers__date"><?php echo esc_html( get_post_meta( get_the_ID(), '_bc_date_added', true ) ?: get_the_date('d.m.Y') ); ?></span>
                    </div>
                </div>
                <a href="<?php the_permalink(); ?>" class="brokers__link btn">Подробнее</a>
            </div>
            <?php
        }
        echo '</div>';
        wp_reset_postdata();
    }
    return ob_get_clean();
}

// Complaint handler
add_action( 'admin_post_nopriv_bc_submit_complaint', 'bc_handle_complaint' );
add_action( 'admin_post_bc_submit_complaint', 'bc_handle_complaint' );
function bc_handle_complaint() {
    if ( ! isset($_POST['bc_complaint_nonce']) || ! wp_verify_nonce( $_POST['bc_complaint_nonce'], 'bc_complaint' ) ) {
        wp_die('Nonce error');
    }
    $broker_id = isset($_POST['broker_id']) ? intval($_POST['broker_id']) : 0;
    $desc = isset($_POST['description']) ? sanitize_textarea_field( $_POST['description'] ) : '';
    $title = $broker_id ? 'Жалоба: '. get_the_title($broker_id) : 'Жалоба';
    $post_id = wp_insert_post( array(
        'post_type' => 'complaint',
        'post_title' => $title,
        'post_content' => $desc,
        'post_status' => 'publish',
    ) );
    if ( $post_id && $broker_id ) update_post_meta( $post_id, '_bc_complaint_broker', $broker_id );
    wp_safe_redirect( wp_get_referer() );
    exit;
}

// Flush rewrite on theme activation
add_action( 'after_switch_theme', function(){ flush_rewrite_rules(); } );

// =============================================
// DYNAMIC COUNTERS FOR HOMEPAGE (Facts)
// =============================================

function bc_count_recent_comments( $days = 7 ) {
    global $wpdb;
    $since = date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );
    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = '1' AND comment_date >= %s",
        $since
    ) );
}

function bc_count_blacklisted_brokers() {
    $possible = array( 'мошенник', 'moшeнник', 'scammer', 'fraud', 'fraudster', 'moshennik' );
    $term_ids = array();
    foreach ( $possible as $t ) {
        $term = get_term_by( 'slug', sanitize_title($t), 'broker_status' );
        if ( $term && ! is_wp_error( $term ) ) $term_ids[] = $term->term_id;
    }
    $all = get_terms( array( 'taxonomy' => 'broker_status', 'hide_empty' => false ) );
    if ( ! is_wp_error( $all ) ) {
        foreach ( $all as $term ) {
            if ( mb_stripos( $term->name, 'мошен' ) !== false || mb_stripos( $term->name, 'scamm' ) !== false || mb_stripos($term->name, 'fraud') !== false ) {
                $term_ids[] = $term->term_id;
            }
        }
    }
    $term_ids = array_unique( $term_ids );
    if ( empty( $term_ids ) ) {
        $q = new WP_Query( array( 'post_type'=>'broker','posts_per_page'=>-1,'s'=>'мошенник','fields'=>'ids' ) );
        return $q->found_posts;
    }
    $q = new WP_Query( array(
        'post_type' => 'broker',
        'posts_per_page' => -1,
        'tax_query' => array( array( 'taxonomy'=>'broker_status','field'=>'term_id','terms'=>$term_ids ) ),
        'fields' => 'ids',
    ) );
    return $q->found_posts;
}

function bc_count_recent_complaints( $days = 7 ) {
    $q = new WP_Query( array(
        'post_type' => 'complaint',
        'post_status' => 'publish',
        'date_query' => array( array( 'after' => "{$days} days ago" ) ),
        'posts_per_page' => -1,
        'fields' => 'ids',
    ) );
    return $q->found_posts;
}

function bc_count_recent_news( $days = 7 ) {
    $q = new WP_Query( array(
        'post_type' => 'bc_news',
        'post_status' => 'publish',
        'date_query' => array( array( 'after' => "{$days} days ago" ) ),
        'posts_per_page' => -1,
        'fields' => 'ids',
    ) );
    return $q->found_posts;
}

function bc_format_count( $n ) {
    return intval($n);
}