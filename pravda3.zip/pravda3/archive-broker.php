<?php
// archive-broker.php — каталог брокеров с хлебными крошками, нормальным лого и пагинацией
get_header();
?>
<main class="page">
  <section class="search-broker">
    <div class="search-broker__container">

      <!-- Хлебные крошки -->
      <nav class="bc-breadcrumbs" aria-label="Хлебные крошки">
        <a href="<?php echo esc_url(home_url('/')); ?>">Главная</a>
        <span class="sep">›</span>
        <span class="current">Поиск брокера</span>
      </nav>

      <!-- Шапка с поиском -->
      <div class="search-broker__body">
        <div class="search-broker__content">
          <h2 class="search-broker__title title title--white">Поиск брокера</h2>
          <form action="<?php echo esc_url(get_post_type_archive_link('broker')); ?>" method="get" class="search-broker__form">
            <input autocomplete="off" type="text" name="s" placeholder="Поиск" class="search-broker__input" value="<?php echo get_search_query(); ?>">
            <button type="submit" class="search-broker__button"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/search.svg" alt=""></button>
          </form>
        </div>
        <div class="search-broker__image">
          <picture><source srcset="<?php echo get_template_directory_uri(); ?>/img/broker.webp" type="image/webp"><img src="<?php echo get_template_directory_uri(); ?>/img/broker.jpg" alt=""></picture>
        </div>
      </div>

      <!-- Сетка брокеров -->
      <div class="search-broker__brokers brokers">
        <?php if (have_posts()) : while (have_posts()) : the_post();
          $terms = wp_get_post_terms(get_the_ID(), 'broker_status');
          $status_name = ($terms && !is_wp_error($terms)) ? $terms[0]->name : '-';
          $rating = get_post_meta(get_the_ID(), '_bc_rating', true) ?: 0;
          $logo_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');
        ?>
        <div class="brokers__block">
          <a href="<?php the_permalink(); ?>" class="brokers__left">
            <span class="brokers__logo">
              <?php if ($logo_url) : ?>
                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php the_title_attribute(); ?>" class="broker-logo-img">
              <?php else : ?>
                <span class="broker-logo-placeholder"><?php echo mb_substr(get_the_title(), 0, 2); ?></span>
              <?php endif; ?>
            </span>
            <h3 class="brokers__name"><?php the_title(); ?></h3>
          </a>
          <div class="brokers__content">
            <p class="brokers__status">Статус: <strong><?php echo esc_html($status_name); ?></strong></p>
            <div class="brokers__date-block">
              <span class="brokers__date"><?php echo esc_html(get_post_meta(get_the_ID(),'_bc_date_added',true) ?: get_the_date('d.m.Y')); ?></span>
            </div>
          </div>
          <a href="<?php the_permalink(); ?>" class="brokers__link btn">Подробнее</a>
        </div>
        <?php endwhile;
        else: ?>
        <p style="padding:2rem;color:#fff;">Брокеры не найдены.</p>
        <?php endif; ?>
      </div>

      <!-- Пагинация -->
      <?php if ($GLOBALS['wp_query']->max_num_pages > 1) : ?>
      <div class="bc-pagination">
        <?php
        the_posts_pagination(array(
          'mid_size'  => 2,
          'prev_text' => '← Назад',
          'next_text' => 'Вперёд →',
        ));
        ?>
      </div>
      <?php endif; ?>

    </div>
  </section>
</main>

<style>
/* === ЛОГО БРОКЕРА В КАТАЛОГЕ === */
.brokers__logo {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 200px !important;
  height: 64px !important;
  border-radius: 12px !important;
  overflow: hidden !important;
  flex-shrink: 0 !important;
  border: 1px solid rgba(0,0,0,0.08) !important;
}
.broker-logo-img {
  width: 100% !important;
  height: 100% !important;
  object-fit: contain !important;
  padding: 6px !important;
}
.broker-logo-placeholder {
  font-size: 1.375rem !important;
  font-weight: 700 !important;
  color: #444 !important;
  text-transform: uppercase !important;
  font-family: 'Oswald', sans-serif !important;
}

/* === ПАГИНАЦИЯ === */
.bc-pagination { margin: 2.5rem 0 1rem; display: flex; justify-content: center; }
.bc-pagination .nav-links { display: flex !important; align-items: center !important; gap: 0.5rem !important; flex-wrap: wrap !important; justify-content: center !important; }
.bc-pagination .page-numbers {
  display: flex !important; align-items: center !important; justify-content: center !important;
  min-width: 2.5rem !important; height: 2.5rem !important; padding: 0 0.75rem !important;
  border-radius: 10px !important; font-size: 0.9375rem !important; font-weight: 600 !important;
  background: #efefef !important; color: #333 !important;
  text-decoration: none !important; transition: all 0.2s !important;
  border: 2px solid transparent !important;
}
.bc-pagination .page-numbers:hover { background: rgba(245,79,8,0.1) !important; border-color: rgba(245,79,8,0.4) !important; color: rgba(245,79,8,0.99) !important; }
.bc-pagination .page-numbers.current { background: rgba(245,79,8,0.99) !important; color: #fff !important; border-color: rgba(245,79,8,0.99) !important; }
.bc-pagination .page-numbers.dots { background: transparent !important; border: none !important; }
.bc-pagination .prev, .bc-pagination .next { font-size: 0.875rem !important; }

/* === ХЛЕБНЫЕ КРОШКИ === */
.bc-breadcrumbs { display: flex; align-items: center; flex-wrap: wrap; gap: 0.375rem; padding: 1rem 0 0.5rem; font-size: 0.875rem; }
.bc-breadcrumbs a { color: rgba(245,79,8,0.9); text-decoration: none; }
.bc-breadcrumbs a:hover { text-decoration: underline; }
.bc-breadcrumbs .sep { color: #aaa; }
.bc-breadcrumbs .current { color: #888; }
</style>

<?php get_footer(); ?>