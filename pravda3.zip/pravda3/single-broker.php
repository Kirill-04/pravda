<?php
// single-broker.php
get_header();
if (have_posts()) : while (have_posts()) : the_post();
  $post_id     = get_the_ID();
  $rating      = get_post_meta($post_id, '_bc_rating', true) ?: 0;
  $status      = wp_get_post_terms($post_id, 'broker_status');
  $status_name = ($status && !is_wp_error($status)) ? $status[0]->name : '';
  $logo_url    = get_the_post_thumbnail_url($post_id, 'large');
?>
<main class="page">

  <!-- ВЕРХНИЙ БЛОК БРОКЕРА -->
  <section class="top-broker">
    <div class="top-broker__container">

      <!-- Хлебные крошки -->
      <nav class="bc-breadcrumbs" aria-label="Хлебные крошки">
        <a href="<?php echo esc_url(home_url('/')); ?>">Главная</a>
        <span class="sep">›</span>
        <a href="<?php echo esc_url(home_url('/brokers/')); ?>">Поиск брокера</a>
        <span class="sep">›</span>
        <span class="current"><?php the_title(); ?></span>
      </nav>

      <div class="top-broker__body">
        <div class="top-broker__content">

          <!-- Лого брокера -->
          <div class="top-broker__image broker-logo-wrap">
            <?php if ($logo_url) : ?>
              <img src="<?php echo esc_url($logo_url); ?>" alt="<?php the_title_attribute(); ?>" class="broker-logo-main">
            <?php else : ?>
              <span class="broker-logo-fallback"><?php echo mb_substr(get_the_title(), 0, 2); ?></span>
            <?php endif; ?>
          </div>

          <div class="top-broker__info">
            <div class="top-broker__status">
              <div class="top-broker__icon"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/check2.svg" alt=""></div>
              <p class="top-broker__info-status">Статус: <?php echo esc_html($status_name); ?></p>
            </div>
            <h1 class="top-broker__name"><?php the_title(); ?></h1>
            <div class="top-broker__rating">
              <div class="top-broker__rating-block">
                <span class="top-broker__number"><?php echo esc_html($rating); ?></span>
                <ul class="top-broker__rating-list">
                  <?php for ($i=0; $i<5; $i++) : ?>
                  <li class="top-broker__rating-item"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/star-white.svg" alt=""></li>
                  <?php endfor; ?>
                </ul>
              </div>
              <a href="#reviews" class="top-broker__reviews-link">Отзывов: <?php echo get_comments_number(); ?></a>
            </div>
            <ul class="top-broker__links">
              <li><a href="#overview" class="top-broker__link-bottom btn">Обзор</a></li>
              <li><a href="#reviews" class="top-broker__link-bottom btn">Отзывы</a></li>
              <li><a href="#facts" class="top-broker__link-bottom btn">FAQ</a></li>
            </ul>
          </div>
        </div>
      </div>

      <!-- ОБЗОР -->
      <div id="overview" class="top-broker__block block-top-broker">
        <h2 class="block-top-broker__title"><?php the_title(); ?> — обзор</h2>
        <div class="block-top-broker__text"><?php the_content(); ?></div>
        <a href="#wait-review" class="block-top-broker__link btn">Оставить отзыв <img src="<?php echo get_template_directory_uri(); ?>/img/icons/reviews-white.svg" alt="иконка"></a>
      </div>

      <!-- ОТЗЫВЫ -->
      <section id="reviews" class="reviews-block">
        <div class="reviews-block__container">
          <h2 class="reviews-block__title">Отзывы</h2>
          <div class="reviews-block__body">
            <?php
            $comments = get_comments(array('post_id'=>$post_id,'status'=>'approve'));
            if ($comments) :
              foreach ($comments as $c) :
                $rating_val = get_comment_meta($c->comment_ID, 'bc_rating', true);
            ?>
            <div class="reviews-block__item item-reviews-block">
              <div class="item-reviews-block__image">
                <img src="<?php echo get_avatar_url($c->comment_author_email ?: $c->comment_author, array('size'=>64)); ?>" alt="">
              </div>
              <div class="item-reviews-block__content">
                <h3 class="item-reviews-block__name"><?php echo esc_html($c->comment_author); ?></h3>
                <span class="item-reviews-block__date"><?php echo date('d.m.Y', strtotime($c->comment_date)); ?></span>
                <?php if ($rating_val) : ?>
                <div class="item-reviews-block__rating">
                  <?php for ($i=1; $i<=5; $i++) : ?>
                  <span class="fire-star<?php echo $i <= $rating_val ? ' fire-star--active' : ''; ?>">🔥</span>
                  <?php endfor; ?>
                </div>
                <?php endif; ?>
                <p class="item-reviews-block__text"><?php echo wp_trim_words($c->comment_content, 30); ?></p>
              </div>
            </div>
            <?php endforeach;
            else: ?>
            <p>Нет отзывов. Будьте первым!</p>
            <?php endif; ?>
          </div>
          <div class="bc-pagination"><?php paginate_comments_links(array('prev_text'=>'← Назад','next_text'=>'Вперёд →')); ?></div>
        </div>
      </section>

      <!-- ФОРМА ОТЗЫВА -->
      <section id="wait-review" class="wait-review">
        <div class="wait-review__container">
          <div class="wait-review__body">
            <form action="<?php echo site_url('/wp-comments-post.php'); ?>" method="post" class="wait-review__form">
              <h2 class="wait-review__title">Оставьте свой отзыв</h2>
              <input type="hidden" name="comment_post_ID" value="<?php echo $post_id; ?>">
              <input type="hidden" name="redirect_to" value="<?php the_permalink(); ?>">
              <?php wp_nonce_field(''); ?>

              <!-- Рейтинг огонёк -->
              <div class="wait-review__rating">
                <p>Ваша оценка:</p>
                <div class="fire-selector" id="fireSelector">
                  <?php for ($i=1; $i<=5; $i++) : ?>
                  <span class="fire-opt" data-val="<?php echo $i; ?>">🔥</span>
                  <?php endfor; ?>
                </div>
                <input type="hidden" name="bc_rating" id="fireRatingInput" value="">
                <small>Нажмите на огонь чтобы выбрать оценку</small>
              </div>

              <input autocomplete="off" type="text" name="author" placeholder="Имя" class="wait-review__input" required>
              <input autocomplete="off" type="email" name="email" placeholder="Email" class="wait-review__input">
              <textarea name="comment" placeholder="Текст отзыва" class="wait-review__input wait-review__input--txt" required></textarea>
              <button type="submit" class="wait-review__button btn">Отправить отзыв</button>
            </form>
          </div>
        </div>
      </section>

      <!-- FAQ -->
      <?php
      $faqs = get_posts(array(
        'post_type'      => 'bc_faq',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_query'     => array(
          'relation' => 'OR',
          array('key'=>'_bc_faq_broker_id','value'=>$post_id,'compare'=>'='),
          array('key'=>'_bc_faq_broker_id','value'=>'','compare'=>'='),
          array('key'=>'_bc_faq_broker_id','compare'=>'NOT EXISTS'),
        ),
        'orderby'        => 'meta_value_num',
        'meta_key'       => '_bc_faq_order',
        'order'          => 'ASC',
      ));
      if ($faqs) :
      ?>
      <section id="facts" class="bc-faq-section">
        <h2 class="bc-faq-title">FAQ — Часто задаваемые вопросы</h2>
        <div class="bc-faq-list">
          <?php foreach ($faqs as $faq) :
            $answer = get_post_meta($faq->ID, '_bc_faq_answer', true) ?: apply_filters('the_content', $faq->post_content);
          ?>
          <div class="bc-faq-item">
            <button class="bc-faq-question" type="button" aria-expanded="false">
              <?php echo esc_html($faq->post_title); ?>
              <span class="bc-faq-icon">+</span>
            </button>
            <div class="bc-faq-answer" hidden>
              <div class="bc-faq-answer-inner"><?php echo wp_kses_post($answer); ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>

    </div>
  </section>

  <!-- ПОХОЖИЕ ОБЗОРЫ -->
  <?php
  $similar = new WP_Query(array(
    'post_type'      => 'broker',
    'posts_per_page' => 9,
    'post__not_in'   => array($post_id),
    'orderby'        => 'rand',
    'post_status'    => 'publish',
  ));
  if ($similar->have_posts()) :
  ?>
  <section class="similar-brokers">
    <div class="similar-brokers__container">
      <div class="similar-brokers__head">
        <h2 class="similar-brokers__title title">Похожие обзоры</h2>
        <div class="similar-brokers__nav">
          <button class="sim-btn sim-btn--prev" id="simPrev" aria-label="Назад">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <button class="sim-btn sim-btn--next" id="simNext" aria-label="Вперёд">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
        </div>
      </div>
      <div class="similar-brokers__track-wrap">
        <div class="similar-brokers__track" id="simTrack">
          <?php while ($similar->have_posts()) : $similar->the_post();
            $s_logo    = get_the_post_thumbnail_url(get_the_ID(), 'thumbnail');
            $s_rating  = get_post_meta(get_the_ID(), '_bc_rating', true) ?: 0;
            $s_terms   = wp_get_post_terms(get_the_ID(), 'broker_status');
            $s_status  = ($s_terms && !is_wp_error($s_terms)) ? $s_terms[0]->name : '-';
            $is_scam   = mb_stripos($s_status, 'мошен') !== false || mb_stripos($s_status, 'scam') !== false || mb_stripos($s_status, 'fraud') !== false;
          ?>
          <a href="<?php the_permalink(); ?>" class="sim-card">
            <div class="sim-card__logo">
              <?php if ($s_logo) : ?>
              <img src="<?php echo esc_url($s_logo); ?>" alt="<?php the_title_attribute(); ?>">
              <?php else : ?>
              <span class="sim-card__logo-placeholder"><?php echo mb_substr(get_the_title(),0,2); ?></span>
              <?php endif; ?>
            </div>
            <h3 class="sim-card__name"><?php the_title(); ?></h3>
            <div class="sim-card__rating">
              <?php
              $stars = round($s_rating);
              for ($i=1; $i<=5; $i++) echo '<span class="sim-star'.($i<=$stars?' sim-star--on':'').'">★</span>';
              ?>
              <span class="sim-card__num"><?php echo number_format($s_rating,1); ?></span>
            </div>
            <div class="sim-card__status <?php echo $is_scam ? 'sim-card__status--bad' : 'sim-card__status--ok'; ?>">
              <?php echo esc_html($s_status); ?>
            </div>
          </a>
          <?php endwhile; wp_reset_postdata(); ?>
        </div>
      </div>
    </div>
  </section>
  <?php endif; ?>

</main>

<style>
/* === ЛОГО БРОКЕРА НА СТРАНИЦЕ === */
.broker-logo-wrap {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 180px !important;
  height: 120px !important;
  background: #fff !important;
  border-radius: 16px !important;
  border: 1px solid rgba(0,0,0,0.1) !important;
  overflow: hidden !important;
  flex-shrink: 0 !important;
  padding: 12px !important;
}
.broker-logo-main {
  max-width: 100% !important;
  max-height: 100% !important;
  object-fit: contain !important;
  width: 100% !important;
  height: 100% !important;
}
.broker-logo-fallback {
  font-size: 2.5rem !important;
  font-weight: 900 !important;
  color: #333 !important;
  font-family: 'Oswald', sans-serif !important;
  text-transform: uppercase !important;
}
@media (max-width: 47.99875em) {
  .broker-logo-wrap { width: 120px !important; height: 80px !important; }
}

/* === ОГОНЁК РЕЙТИНГ === */
.fire-selector { display: flex; gap: 0.375rem; margin: 0.5rem 0; }
.fire-opt { font-size: 1.75rem; cursor: pointer; filter: grayscale(1); transition: filter 0.15s, transform 0.15s; }
.fire-opt.active, .fire-opt:hover { filter: none; transform: scale(1.15); }
.fire-star { font-size: 1rem; filter: grayscale(1); }
.fire-star--active { filter: none; }
.item-reviews-block__rating { display: flex; gap: 3px; margin: 4px 0; }
.wait-review__rating { margin: 1rem 0; }
.wait-review__rating p { margin-bottom: 0.375rem; font-weight: 600; }
.wait-review__rating small { color: #888; font-size: 0.8125rem; display: block; margin-top: 0.25rem; }

/* === FAQ === */
.bc-faq-section { margin: 2rem 0; }
.bc-faq-title { font-size: 1.5rem; font-weight: 700; margin-bottom: 1.25rem; color: #1d1d1d; }
.bc-faq-item { border: 1px solid rgba(0,0,0,0.09); border-radius: 12px; margin-bottom: 0.625rem; overflow: hidden; }
.bc-faq-question { width: 100%; text-align: left; padding: 1rem 1.25rem; background: #f9f9f9; border: none; cursor: pointer; font-size: 1rem; font-weight: 600; color: #1d1d1d; display: flex; justify-content: space-between; align-items: center; gap: 1rem; transition: background 0.2s; }
.bc-faq-question:hover, .bc-faq-question[aria-expanded="true"] { background: rgba(245,79,8,0.05); }
.bc-faq-icon { font-size: 1.375rem; font-weight: 300; color: rgba(245,79,8,0.9); transition: transform 0.2s; flex-shrink: 0; }
.bc-faq-question[aria-expanded="true"] .bc-faq-icon { transform: rotate(45deg); }
.bc-faq-answer { overflow: hidden; }
.bc-faq-answer-inner { padding: 1rem 1.25rem; color: #333; line-height: 1.7; }

/* === ПОХОЖИЕ ОБЗОРЫ === */
.similar-brokers { padding: 3rem 0; }
.similar-brokers__container { max-width: 1400px; margin: 0 auto; padding: 0 1.25rem; }
.similar-brokers__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
.similar-brokers__title { margin: 0 !important; }
.similar-brokers__nav { display: flex; gap: 0.625rem; }
.sim-btn { width: 2.75rem; height: 2.75rem; border-radius: 50%; background: #222; color: #fff; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: background 0.2s; }
.sim-btn:hover { background: rgba(245,79,8,0.9); }
.sim-btn:disabled { opacity: 0.3; cursor: default; }

.similar-brokers__track-wrap { overflow: hidden; }
.similar-brokers__track {
  display: flex;
  gap: 1rem;
  transition: transform 0.35s ease;
}
.sim-card {
  flex: 0 0 calc((100% - 4rem) / 4);
  min-width: 0;
  background: #fff;
  border: 1px solid rgba(0,0,0,0.08);
  border-radius: 16px;
  padding: 1.25rem;
  text-decoration: none;
  color: inherit;
  transition: box-shadow 0.2s, transform 0.2s;
  display: flex;
  flex-direction: column;
  gap: 0.625rem;
}
.sim-card:hover { box-shadow: 0 8px 24px rgba(0,0,0,0.12); transform: translateY(-3px); }

.sim-card__logo { width: 100%; height: 60px; display: flex; align-items: center; justify-content: center; background: #f5f5f5; border-radius: 10px; overflow: hidden; }
.sim-card__logo img { max-width: 100%; max-height: 100%; object-fit: contain; padding: 6px; }
.sim-card__logo-placeholder { font-size: 1.375rem; font-weight: 700; color: #555; font-family: 'Oswald', sans-serif; }
.sim-card__name { font-size: 0.9375rem; font-weight: 700; color: #1d1d1d; margin: 0; line-height: 1.3; }
.sim-card__rating { display: flex; align-items: center; gap: 2px; }
.sim-star { font-size: 0.875rem; color: #ccc; }
.sim-star--on { color: #f5a623; }
.sim-card__num { font-size: 0.8125rem; color: #666; margin-left: 4px; }
.sim-card__status { font-size: 0.8125rem; font-weight: 600; padding: 0.25rem 0.625rem; border-radius: 6px; display: inline-block; }
.sim-card__status--bad { background: rgba(220,50,50,0.1); color: #c0392b; }
.sim-card__status--ok  { background: rgba(39,174,96,0.1);  color: #27ae60; }

@media (max-width: 61.99875em) {
  .sim-card { flex: 0 0 calc((100% - 2rem) / 2); }
}
@media (max-width: 35em) {
  .sim-card { flex: 0 0 calc(100% - 2rem); }
}

/* === ХЛЕБНЫЕ КРОШКИ === */
.bc-breadcrumbs { display: flex; align-items: center; flex-wrap: wrap; gap: 0.375rem; padding: 1rem 0 0.5rem; font-size: 0.875rem; }
.bc-breadcrumbs a { color: rgba(245,79,8,0.9); text-decoration: none; }
.bc-breadcrumbs a:hover { text-decoration: underline; }
.bc-breadcrumbs .sep { color: #aaa; }
.bc-breadcrumbs .current { color: #888; }

/* === ПАГИНАЦИЯ === */
.bc-pagination .nav-links { display: flex !important; align-items: center !important; gap: 0.5rem !important; flex-wrap: wrap !important; justify-content: center !important; margin: 1.5rem 0 !important; }
.bc-pagination .page-numbers { display: flex !important; align-items: center !important; justify-content: center !important; min-width: 2.5rem !important; height: 2.5rem !important; padding: 0 0.75rem !important; border-radius: 10px !important; font-size: 0.9375rem !important; font-weight: 600 !important; background: #efefef !important; color: #333 !important; text-decoration: none !important; transition: all 0.2s !important; border: 2px solid transparent !important; }
.bc-pagination .page-numbers:hover { background: rgba(245,79,8,0.1) !important; border-color: rgba(245,79,8,0.4) !important; color: rgba(245,79,8,0.99) !important; }
.bc-pagination .page-numbers.current { background: rgba(245,79,8,0.99) !important; color: #fff !important; border-color: rgba(245,79,8,0.99) !important; }
.bc-pagination .page-numbers.dots { background: transparent !important; border: none !important; }
</style>

<script>
// FAQ accordion
document.querySelectorAll('.bc-faq-question').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var item   = btn.closest('.bc-faq-item');
    var answer = item.querySelector('.bc-faq-answer');
    var isOpen = btn.getAttribute('aria-expanded') === 'true';
    // Закрыть все
    document.querySelectorAll('.bc-faq-question').forEach(function(b) {
      b.setAttribute('aria-expanded', 'false');
      b.closest('.bc-faq-item').querySelector('.bc-faq-answer').hidden = true;
    });
    if (!isOpen) {
      btn.setAttribute('aria-expanded', 'true');
      answer.hidden = false;
    }
  });
});

// Огонёк рейтинг
(function() {
  var opts  = document.querySelectorAll('.fire-opt');
  var input = document.getElementById('fireRatingInput');
  if (!opts.length || !input) return;
  opts.forEach(function(opt) {
    opt.addEventListener('click', function() {
      var val = parseInt(opt.dataset.val);
      input.value = val;
      opts.forEach(function(o) {
        o.classList.toggle('active', parseInt(o.dataset.val) <= val);
      });
    });
  });
})();

// Похожие обзоры — карусель
(function() {
  var track   = document.getElementById('simTrack');
  var btnPrev = document.getElementById('simPrev');
  var btnNext = document.getElementById('simNext');
  if (!track || !btnPrev || !btnNext) return;

  var cards      = track.querySelectorAll('.sim-card');
  var total      = cards.length;
  var current    = 0;
  var perView    = 4;

  function getPerView() {
    if (window.innerWidth < 560)  return 1;
    if (window.innerWidth < 992)  return 2;
    return 4;
  }

  function updateCarousel() {
    perView = getPerView();
    var maxSlide = Math.max(0, total - perView);
    if (current > maxSlide) current = maxSlide;
    var cardW = cards[0] ? (cards[0].offsetWidth + 16) : 0; // gap=1rem=16px
    track.style.transform = 'translateX(-' + (current * cardW) + 'px)';
    btnPrev.disabled = current === 0;
    btnNext.disabled = current >= maxSlide;
  }

  btnPrev.addEventListener('click', function() { if (current > 0) { current--; updateCarousel(); } });
  btnNext.addEventListener('click', function() {
    perView = getPerView();
    if (current < total - perView) { current++; updateCarousel(); }
  });

  window.addEventListener('resize', updateCarousel, { passive: true });
  // Задержка, чтобы DOM отрендерился
  setTimeout(updateCarousel, 100);
})();
</script>

<?php endwhile; endif; get_footer(); ?>