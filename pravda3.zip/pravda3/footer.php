<?php
// footer.php
?>
<footer class="footer">
  <div class="footer__container">
    <div class="footer__left">

      <a href="<?php echo esc_url( home_url('/') ); ?>" class="footer__logo-link" aria-label="<?php bloginfo('name'); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png"
             alt="<?php bloginfo('name'); ?>"
             class="footer__logo-img">
      </a>

      <div class="footer__menu menu-footer">
        <nav class="menu__body" aria-label="Footer меню">
          <?php
          if ( has_nav_menu('primary') ) {
            wp_nav_menu( array(
              'theme_location' => 'primary',
              'container'      => false,
              'menu_class'     => 'menu-footer__list',
            ) );
          } else {
            echo '<ul class="menu-footer__list">
              <li class="menu-footer__item"><a class="menu-footer__link" href="' . esc_url( home_url('/') ) . '">Главная</a></li>
              <li class="menu-footer__item"><a class="menu-footer__link" href="' . esc_url( home_url('/brokers/') ) . '">Поиск брокера</a></li>
              <li class="menu-footer__item"><a class="menu-footer__link" href="' . esc_url( home_url('/black-broker/') ) . '">Чёрный список</a></li>
              <li class="menu-footer__item"><a class="menu-footer__link" href="' . esc_url( home_url('/news/') ) . '">Новости</a></li>
              <li class="menu-footer__item"><a class="menu-footer__link" href="' . esc_url( home_url('/contacts/') ) . '">Контакты</a></li>
              <li class="menu-footer__item"><a class="menu-footer__link" href="' . esc_url( home_url('/complaints/') ) . '">Жалобы</a></li>
            </ul>';
          }
          ?>
        </nav>
      </div>

    </div>

    <div class="footer__right">

      <form action="<?php echo esc_url( home_url('/') ); ?>" method="get" class="footer__form" role="search">
        <input autocomplete="off" type="text" name="s" placeholder="Поиск" class="footer__input" aria-label="Поиск">
        <button type="submit" class="footer__button" aria-label="Найти">
          <img src="<?php echo get_template_directory_uri(); ?>/img/icons/search.svg" alt="">
        </button>
      </form>

      <div class="footer__social">
        <h4 class="footer__social-title">Наши соц сети:</h4>
        <ul class="footer__social-list">
          <li class="footer__social-item">
            <a href="#" aria-label="YouTube">
              <img src="<?php echo get_template_directory_uri(); ?>/img/icons/ytb.svg" alt="YouTube">
            </a>
          </li>
          <li class="footer__social-item">
            <a href="#" aria-label="Facebook">
              <img src="<?php echo get_template_directory_uri(); ?>/img/icons/fb.svg" alt="Facebook">
            </a>
          </li>
          <li class="footer__social-item">
            <a href="#" aria-label="Instagram">
              <img src="<?php echo get_template_directory_uri(); ?>/img/icons/inst.svg" alt="Instagram">
            </a>
          </li>
        </ul>
      </div>

    </div>
  </div>

  <div class="footer__bottom">
    <div class="footer__container">
      <p class="footer__copy">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Все права защищены.</p>
    </div>
  </div>
</footer>

</div><!-- .wrapper -->

<style>
/* =============================================
   FOOTER STYLES
   ============================================= */
.footer {
  background: rgba(22,22,22,0.99);
}

/* Логотип в футере */
.footer__logo-link {
  display: flex;
  align-items: center;
  text-decoration: none;
  flex-shrink: 0;
}
.footer__logo-img {
  height: 40px;
  width: auto;
  max-width: 155px;
  object-fit: contain;
  display: block;
}

/* Меню в футере */
.menu-footer__list {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem 1.5rem;
  list-style: none;
  padding: 0;
  margin: 0;
}
.menu-footer__link {
  color: rgba(255,255,255,0.75);
  font-size: 0.9375rem;
  transition: color 0.2s;
  text-decoration: none;
  white-space: nowrap;
}
.menu-footer__link:hover {
  color: rgba(245,79,8,0.99);
}
/* Если wp_nav_menu генерирует стандартные классы */
.menu-footer .menu__list {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.5rem 1.5rem;
  list-style: none;
  padding: 0;
  margin: 0;
}
.menu-footer .menu__link,
.menu-footer .menu__item > a {
  color: rgba(255,255,255,0.75) !important;
  font-size: 0.9375rem !important;
  transition: color 0.2s !important;
  text-decoration: none !important;
  white-space: nowrap !important;
}
.menu-footer .menu__link:hover,
.menu-footer .menu__item > a:hover {
  color: rgba(245,79,8,0.99) !important;
}
.menu-footer .menu__link::after,
.menu-footer .menu__item > a::after {
  display: none !important;
}

/* Нижняя полоска */
.footer__bottom {
  border-top: 1px solid rgba(255,255,255,0.07);
  padding: 0.875rem 0;
}
.footer__copy {
  color: rgba(255,255,255,0.35);
  font-size: 0.8125rem;
  text-align: center;
  margin: 0;
}

/* =============================================
   FOOTER MOBILE
   ============================================= */
@media (max-width: 767px) {
  .footer__container {
    flex-direction: column !important;
    align-items: center !important;
    text-align: center !important;
    padding-top: 2rem !important;
    padding-bottom: 2rem !important;
    gap: 1.75rem !important;
    min-height: auto !important;
  }
  .footer__left {
    flex-direction: column !important;
    align-items: center !important;
    gap: 1.25rem !important;
    column-gap: 0 !important;
    width: 100% !important;
  }
  .menu-footer__list,
  .menu-footer .menu__list {
    flex-direction: column !important;
    align-items: center !important;
    gap: 0.625rem !important;
  }
  .footer__right {
    flex-direction: column !important;
    align-items: center !important;
    gap: 1.25rem !important;
    column-gap: 0 !important;
    width: 100% !important;
  }
  .footer__form {
    width: 100% !important;
    max-width: 300px !important;
  }
  .footer__social {
    text-align: center !important;
  }
  .footer__social-title {
    font-size: 0.9375rem !important;
    color: rgba(255,255,255,0.6) !important;
    margin-bottom: 0.75rem !important;
  }
  .footer__social-list {
    justify-content: center !important;
  }
}
</style>

<?php wp_footer(); ?>
</body>
</html>