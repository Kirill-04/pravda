<?php // header.php ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
<style>
/* LOGO */
.header .logo{display:flex!important;align-items:center!important;flex-shrink:0!important;overflow:visible!important;font-size:0!important;text-decoration:none!important;}
.header .logo img{height:42px!important;width:auto!important;max-width:160px!important;object-fit:contain!important;display:block!important;}
.header .logo::before{display:none!important;}
/* CONTAINERS */
[class*="__container"]{max-width:1400px!important;width:100%!important;box-sizing:border-box!important;margin-left:auto!important;margin-right:auto!important;padding-left:1.25rem!important;padding-right:1.25rem!important;}
/* HERO offset */
.hero{margin-top:5.75rem!important;}
@media(max-width:61.99875em){.hero{margin-top:5.25rem!important;}}
@media(max-width:29.99875em){.hero{margin-top:4.75rem!important;}}
/* DESKTOP: menu is static flex */
@media(min-width:62em){
  .menu{position:static!important;transform:none!important;background:transparent!important;height:auto!important;overflow:visible!important;padding:0!important;pointer-events:all!important;opacity:1!important;visibility:visible!important;display:flex!important;}
  .menu-overlay{display:none!important;}
  .icon-menu{display:none!important;}
}
/* MOBILE MENU */
@media(max-width:61.99875em){
  .icon-menu{display:block!important;z-index:1001!important;position:relative!important;}
  .menu{position:fixed!important;top:0!important;left:0!important;width:100%!important;height:100%!important;overflow-y:auto!important;padding:5.5rem 1.5rem 2rem!important;background:rgba(18,18,18,0.98)!important;backdrop-filter:blur(14px)!important;-webkit-backdrop-filter:blur(14px)!important;transform:translateX(-100%)!important;transition:transform 0.35s cubic-bezier(0.4,0,0.2,1)!important;z-index:999!important;display:flex!important;flex-direction:column!important;align-items:center!important;gap:2rem!important;pointer-events:none!important;visibility:hidden!important;}
  .menu-open .menu{transform:translateX(0)!important;pointer-events:all!important;visibility:visible!important;}
  .menu .menu__body{width:100%!important;max-width:340px!important;}
  .menu .menu__list{flex-direction:column!important;align-items:stretch!important;gap:0.375rem!important;width:100%!important;}
  .menu .menu__item{width:100%!important;}
  .menu .menu__link,.menu .menu__item>a{font-size:1.125rem!important;padding:0.875rem 1.25rem!important;text-align:center!important;border-radius:12px!important;border:1px solid rgba(255,255,255,0.07)!important;display:block!important;color:rgba(255,255,255,0.85)!important;}
  .menu .menu__link:hover,.menu .menu__item>a:hover{background:rgba(245,79,8,0.12)!important;border-color:rgba(245,79,8,0.28)!important;color:#fff!important;}
  .menu .menu__social{text-align:center!important;width:100%!important;max-width:340px!important;}
  .menu .menu__social-title{color:rgba(255,255,255,0.5)!important;font-size:0.875rem!important;margin-bottom:0.75rem!important;}
  .menu .menu__social-list{justify-content:center!important;gap:0.875rem!important;}
}

/* FOOTER logo */
.footer .logo{display:flex!important;align-items:center!important;flex-shrink:0!important;}
.footer .logo img{height:40px!important;width:auto!important;max-width:155px!important;object-fit:contain!important;display:block!important;}
.footer .logo::before{display:none!important;}
@media(max-width:47.99875em){
  .footer__container{flex-direction:column!important;align-items:center!important;text-align:center!important;padding-top:2rem!important;padding-bottom:2rem!important;gap:2rem!important;min-height:auto!important;}
  .footer__left{flex-direction:column!important;align-items:center!important;gap:1.25rem!important;column-gap:0!important;width:100%!important;}
  .footer__right{flex-direction:column!important;align-items:center!important;gap:1.25rem!important;column-gap:0!important;width:100%!important;}
  .menu-footer__list,.footer .menu__list{flex-direction:column!important;align-items:center!important;gap:0.625rem!important;}
  .footer__form{width:100%!important;max-width:300px!important;}
  .footer__social,.footer__social-list{text-align:center!important;justify-content:center!important;}
}
/* CONTENT HEADINGS */
.post__body h1,.post__body h2,.post__body h3,.post__body h4,.post__body h5,.post__body h6,
.block-top-broker h1,.block-top-broker h2,.block-top-broker h3,.block-top-broker h4,
.page__content h1,.page__content h2,.page__content h3,.page__content h4,
.entry-content h1,.entry-content h2,.entry-content h3,.entry-content h4{font-family:'Roboto','Oswald',sans-serif!important;font-weight:700!important;line-height:1.3!important;color:#1d1d1d!important;margin-top:1.75rem!important;margin-bottom:0.875rem!important;}
.post__body h2,.block-top-broker h2,.entry-content h2{font-size:1.625rem!important;padding-bottom:0.5rem!important;border-bottom:2px solid rgba(245,79,8,0.15)!important;text-transform:uppercase!important;}
.post__body h3,.block-top-broker h3,.entry-content h3{font-size:1.25rem!important;text-transform:uppercase!important;}
.post__body h4,.block-top-broker h4,.entry-content h4{font-size:1.0625rem!important;}
.post__body p,.block-top-broker p{font-size:1rem!important;line-height:1.75!important;color:#333!important;margin-bottom:1rem!important;}
.post__body strong,.block-top-broker strong,.entry-content strong{font-weight:700!important;color:#111!important;}
.post__body a,.block-top-broker a,.entry-content a{color:rgba(245,79,8,0.99)!important;text-decoration:underline!important;}
.post__body ul,.block-top-broker ul,.entry-content ul{padding-left:1.375rem!important;margin-bottom:1rem!important;}
.post__body ul li,.block-top-broker ul li,.entry-content ul li{list-style:disc!important;line-height:1.7!important;margin-bottom:0.35rem!important;color:#333!important;}
.post__body ol,.block-top-broker ol,.entry-content ol{padding-left:1.375rem!important;margin-bottom:1rem!important;}
.post__body ol li,.block-top-broker ol li,.entry-content ol li{list-style:decimal!important;line-height:1.7!important;margin-bottom:0.35rem!important;color:#333!important;}
</style>
</head>
<body <?php body_class(); ?>>
<div class="wrapper">
<div class="menu-overlay" id="menuOverlay"></div>
<header class="header" id="siteHeader">
  <div class="header__container">
    <div class="header__body">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="logo" aria-label="<?php bloginfo('name'); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="<?php bloginfo('name'); ?>">
      </a>
      <div class="menu" id="siteMenu">
        <div class="menu__logo">the-pravda</div>
        <div class="menu__body">
          <?php
          if (has_nav_menu('primary')) {
            wp_nav_menu(array('theme_location'=>'primary','container'=>false,'menu_class'=>'menu__list'));
          } else {
            echo '<ul class="menu__list">
              <li class="menu__item"><a class="menu__link" href="'.esc_url(home_url('/')).'">Главная</a></li>
              <li class="menu__item"><a class="menu__link" href="'.esc_url(home_url('/brokers/')).'">Поиск брокера</a></li>
              <li class="menu__item"><a class="menu__link" href="'.esc_url(home_url('/black-broker/')).'">Чёрный список</a></li>
              <li class="menu__item"><a class="menu__link" href="'.esc_url(home_url('/news/')).'">Новости</a></li>
              <li class="menu__item"><a class="menu__link" href="'.esc_url(home_url('/contacts/')).'">Контакты</a></li>
              <li class="menu__item"><a class="menu__link" href="'.esc_url(home_url('/complaints/')).'">Жалобы</a></li>
            </ul>';
          }
          ?>
        </div>
        <div class="menu__social">
          <h4 class="menu__social-title">Наши соц сети:</h4>
          <ul class="menu__social-list">
            <li class="menu__social-item"><a class="menu__social-link" href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/ytb.svg" alt="YouTube"></a></li>
            <li class="menu__social-item"><a class="menu__social-link" href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/fb.svg" alt="Facebook"></a></li>
            <li class="menu__social-item"><a class="menu__social-link" href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/inst.svg" alt="Instagram"></a></li>
          </ul>
        </div>
      </div>
      <div class="header__right">
        <form data-da=".menu,479.98" action="<?php echo esc_url(home_url('/')); ?>" method="get" class="header__form">
          <input autocomplete="off" type="text" name="s" placeholder="Поиск" class="header__input" value="<?php echo get_search_query(); ?>">
          <button type="submit" class="header__button"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/search.svg" alt=""></button>
        </form>
        <button type="button" class="icon-menu" id="burgerBtn" aria-label="Открыть меню" aria-expanded="false"><span></span></button>
      </div>
    </div>
  </div>
</header>
