/**
 * mobile-menu.js
 * Управляет мобильным меню через класс .menu-open на <body>
 * Работает с оригинальной HTML-структурой темы pravda3
 *
 * Загрузить в: /wp-content/themes/pravda3/js/mobile-menu.js
 */
(function () {
  'use strict';

  function init() {
    var body    = document.body;
    var burger  = document.querySelector('.icon-menu');
    var header  = document.querySelector('.header');

    if (!burger) return;

    /* ---------- открыть меню ---------- */
    function openMenu() {
      body.classList.add('menu-open');
      body.style.overflow = 'hidden';        // блокируем прокрутку страницы
      burger.setAttribute('aria-expanded', 'true');
    }

    /* ---------- закрыть меню ---------- */
    function closeMenu() {
      body.classList.remove('menu-open');
      body.style.overflow = '';
      burger.setAttribute('aria-expanded', 'false');
    }

    /* ---------- переключить ---------- */
    function toggleMenu() {
      if (body.classList.contains('menu-open')) {
        closeMenu();
      } else {
        openMenu();
      }
    }

    /* ---------- клик по бургеру ---------- */
    burger.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      toggleMenu();
    });

    /* ---------- клик по ссылкам в меню — закрываем ---------- */
    var menuLinks = document.querySelectorAll('.menu .menu__link, .menu a');
    menuLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        closeMenu();
      });
    });

    /* ---------- клавиша Escape ---------- */
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeMenu();
      }
    });

    /* ---------- resize до десктопа — закрываем ---------- */
    window.addEventListener('resize', function () {
      if (window.innerWidth > 992) {
        closeMenu();
      }
    }, { passive: true });

    /* ---------- scroll — класс is-scrolled на хедер ---------- */
    if (header) {
      function onScroll() {
        if (window.scrollY > 60) {
          header.classList.add('is-scrolled');
        } else {
          header.classList.remove('is-scrolled');
        }
      }
      window.addEventListener('scroll', onScroll, { passive: true });
      onScroll(); // проверить сразу при загрузке
    }
  }

  /* Запуск когда DOM готов */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();